# keras-simple-metric-learning
SImple metric learning methods via tf.keras
